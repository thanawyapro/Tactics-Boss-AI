const json = (status, body) => ({ statusCode: status, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify(body) });

const fallbackTips = (lang = 'ar', body = {}) => {
  const formation = body.formation || '4-2-3-1';
  const game = String(body.game || body.gameId || '');
  const note = String(body.userNote || '').toLowerCase();
  const ar = lang === 'ar';
  const tips = [];
  if (/طرف|جناح|wide|wing|flank/.test(note)) {
    tips.push(ar
      ? 'ملاحظتك عن الأطراف: ضع Defensive على RB/LB جهة الخطر، ولو محتاج مرتدة اختَر Counter Target على جناح واحد سريع فقط.'
      : 'Wide danger note: put Defensive on the threatened RB/LB, and use Counter Target on only one fast winger if needed.');
  }
  if (/ضغط|press|pressing/.test(note)) {
    tips.push(ar
      ? 'ملاحظتك عن الضغط: لا تزود التعليمات؛ ابحث عن مخرج تمرير مباشر، وفي PES استخدم Counter Target فقط لو عندك مهاجم يستلم.'
      : 'Pressure note: do not add many instructions; use a direct outlet, and in PES use Counter Target only if you have a receiving forward.');
  }
  if (/سرع|سريع|pace|fast/.test(note)) {
    tips.push(ar
      ? 'ملاحظتك عن السرعة: لا ترفع الخط، وفي eFootball اجعل Deep Line على DMF فقط لحماية العمق.'
      : 'Pace note: do not raise the line; in eFootball use Deep Line on DMF only to protect depth.');
  }
  if (/amf|صانع|بلاي.?ميكر|playmaker|10/.test(note)) {
    tips.push(ar
      ? 'لو الخطر من صانع اللعب: استخدم Man Marking أو Tight Marking على AMF/SS حسب اللعبة، ولا تسحب قلبي الدفاع للمراقبة.'
      : 'If danger is the playmaker: use Man Marking/Tight Marking on AMF/SS where the game supports it; do not pull CBs out.');
  }
  const generic = ar ? [
    `ابدأ بـ ${formation} كما هي، ولا تغيّر أكثر من تعليماتين قبل الدقيقة 30.`,
    game.includes('PES') ? 'في PES استخدم فقط Advanced Instructions الموجودة داخل Game Plan، ولا تعرض Player Styles كأنها تعليمات.' : 'التزم بتعليمات اللعبة المتاحة فقط، ولا تخلط بين PES و eFootball و EA FC.',
    body.mode === 'counter' ? 'راقب جهة هجوم الخصم أول 10 دقائق، ثم فعّل التعليمات الدفاعية المناسبة فقط.' : 'لو الخطة لا تخلق فرصًا، غيّر منطقة الهجوم قبل تغيير التشكيلة.'
  ] : [
    `Start with ${formation}; do not change more than two instructions before minute 30.`,
    'Use only instructions that exist in the selected game.',
    body.mode === 'counter' ? 'Watch the rival attack side for 10 minutes, then apply the defensive instruction.' : 'If chances are weak, change attack area before changing shape.'
  ];
  return [...tips, ...generic].slice(0, 5);
};

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  let body = {};
  try { body = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Invalid JSON' }); }
  const apiKey = process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY;
  if (!apiKey) return json(200, { provider: 'local-fallback', tips: fallbackTips(body.lang, body) });

  const system = `You are Tactic Boss AI Coach. Return ONLY JSON: {"tips":["...","...","..."]}. Each tip must directly respond to the user note first, be short and actionable, and must NOT invent settings outside the selected football game. If PES, only mention PES Game Plan or Advanced Instructions. If eFootball, only mention Team Playstyle/Individual Instructions. If EA FC, only mention FC IQ/Player Roles/Team Tactics.`;
  const user = `Lang: ${body.lang || 'ar'}\nMode: ${body.mode}\nGame: ${body.game}\nFormation: ${body.formation}\nStyle: ${body.style}\nOpponent: ${body.opponentFormation} ${body.opponentStyle}\nMatch state: ${body.matchState}\nUser note: ${body.userNote || ''}\nGive 3-5 tips.`;

  try {
    if (process.env.GEMINI_API_KEY) {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: `${system}\n\n${user}` }] }], generationConfig: { temperature: 0.35, maxOutputTokens: 500, responseMimeType: 'application/json' } })
      });
      const data = await res.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
      const parsed = JSON.parse(text);
      return json(200, { provider: 'gemini', tips: Array.isArray(parsed.tips) ? parsed.tips.slice(0,5) : fallbackTips(body.lang, body) });
    }
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'system', content: system }, { role: 'user', content: user }], temperature: 0.35, response_format: { type: 'json_object' } })
    });
    const data = await res.json();
    const parsed = JSON.parse(data?.choices?.[0]?.message?.content || '{}');
    return json(200, { provider: 'openai', tips: Array.isArray(parsed.tips) ? parsed.tips.slice(0,5) : fallbackTips(body.lang, body) });
  } catch (error) {
    return json(200, { provider: 'local-fallback', tips: fallbackTips(body.lang, body), warning: String(error?.message || error) });
  }
}
