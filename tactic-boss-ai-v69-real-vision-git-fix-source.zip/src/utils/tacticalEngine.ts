import { GameItem } from './gameData';
import { TacticResult } from '../types';
import { applyEfootballManagerToResult } from './efootballManagerEngine';
import { officialDnaForGame, officialDnaSummary } from './officialGameDNA';
import { compactEfootballProfiles, efootballProfileLines } from './efootballPlayerProfiles';

export interface GeneratorInput {
  myFormation: string;
  oppFormation: string;
  opponentStyle: string;
  myStyle: string;
  matchState: string;
  myTeam: string;
  oppTeam: string;
  notes: string;
  efootballManagerId?: string;
}

type GameProfile = {
  formation: string;
  identityAr: string;
  identityEn: string;
  defensiveStyle: string;
  defensiveDetails: Record<string, string>;
  attackingStyle: string;
  attackingDetails: Record<string, string>;
  instructions: string[];
  mistakes: string[];
};

const profiles: Record<string, GameProfile> = {
  'pes-2019': {
    formation: '4-3-1-2',
    identityAr: 'PES 2019 يكافئ زوايا التمرير، تماسك الخطوط، واللعب المباشر المنظم أكثر من الضغط العشوائي.',
    identityEn: 'PES 2019 rewards passing angles, compact lines and organized direct play more than random pressure.',
    defensiveStyle: 'All-out Defence / Conservative',
    defensiveDetails: { 'Containment Area': 'Middle', 'Pressuring': 'Conservative', 'Defensive Line': '4 / 10', 'Compactness': '8 / 10' },
    attackingStyle: 'Possession Game / Short Pass',
    attackingDetails: { 'Build Up': 'Short-pass', 'Attacking Area': 'Centre', 'Positioning': 'Flexible', 'Support Range': '5 / 10', 'Advanced Instructions': 'Anchoring + Defensive' },
    instructions: ['ثبّت لاعب ارتكاز أمام قلبي الدفاع.', 'استخدم صانع اللعب بين الخطوط بدل الجري المستمر.', 'خلّي مهاجم واحد يستلم والثاني يهاجم المساحة.'],
    mistakes: ['رفع الخط الدفاعي زيادة أمام مهاجم سريع.', 'الضغط بقلب الدفاع وترك العمق.', 'التمرير من لمسة واحدة بدون زاوية واضحة.']
  },
  'pes-2020': {
    formation: '4-2-3-1',
    identityAr: 'PES 2020 أبطأ نسبيًا ويحتاج خروجًا هادئًا من الضغط مع استخدام Finesse Dribble في المناطق الآمنة.',
    identityEn: 'PES 2020 is relatively slower and needs calm build-up plus safe use of Finesse Dribble.',
    defensiveStyle: 'All-out Defence / Aggressive',
    defensiveDetails: { 'Containment Area': 'Middle', 'Pressuring': 'Aggressive', 'Defensive Line': '4 / 10', 'Compactness': '8 / 10' },
    attackingStyle: 'Possession Game / Short Pass',
    attackingDetails: { 'Build Up': 'Short-pass', 'Attacking Area': 'Wide', 'Positioning': 'Flexible', 'Support Range': '6 / 10', 'Advanced Instructions': 'Tiki-Taka + Anchoring' },
    instructions: ['استخدم Finesse Dribble للخروج من الضغط وليس أمام منطقة جزائك.', 'ثبّت أحد لاعبي الارتكاز.', 'بدّل اللعب للطرف العكسي عند ضغط الخصم.'],
    mistakes: ['المراوغة قرب المرمى.', 'اندفاع الظهيرين معًا.', 'تغيير المدافع متأخرًا أثناء التحول.']
  },
  'pes-2021': {
    formation: '4-3-1-2',
    identityAr: 'PES 2021 يعتمد بقوة على Team Spirit، تعليمات المدرب، Compactness، وAdvanced Instructions.',
    identityEn: 'PES 2021 strongly depends on Team Spirit, manager instructions, Compactness and Advanced Instructions.',
    defensiveStyle: 'All-out Defence / Aggressive',
    defensiveDetails: { 'Containment Area': 'Middle', 'Pressuring': 'Aggressive', 'Defensive Line': '5 / 10', 'Compactness': '9 / 10' },
    attackingStyle: 'Counter Attack / Short Pass',
    attackingDetails: { 'Build Up': 'Short-pass', 'Attacking Area': 'Centre', 'Positioning': 'Flexible', 'Support Range': '5 / 10', 'Advanced Instructions': 'Anchoring + Counter Target' },
    instructions: ['ارفع Team Spirit قبل تغيير الخطة جذريًا.', 'ضع Counter Target على أخطر مهاجم.', 'خلّي الارتكاز Anchoring ولا تسحبه بعيدًا.'],
    mistakes: ['استخدام تعليمات متقدمة متعارضة.', 'فتح Compactness ضد لعب العمق.', 'رفع Defensive Line أمام مهاجمين سريعين.']
  },
  'efootball-modern': {
    formation: '4-2-1-3',
    identityAr: 'eFootball الحديثة ليست إصدارات سنوية منفصلة؛ هي Live Service يعتمد على Team Playstyle، المدرب، الأدوار الفردية، وتوازن Rest Defence.',
    identityEn: 'Modern eFootball is not separate yearly editions; it is a live-service game built around Team Playstyle, manager fit, individual instructions and rest-defence balance.',
    defensiveStyle: 'Style-aware compact block',
    defensiveDetails: { 'Team Playstyle': 'Quick Counter / Possession / Long Ball Counter / Out Wide / Long Ball', 'Rest Defence': '2 CB + DMF minimum', 'Individual Defence 1': 'Deep Line on DMF when protecting lead or facing pace', 'Individual Defence 2': 'Defensive on one fullback only' },
    attackingStyle: 'Team Playstyle-led attack',
    attackingDetails: { 'Quick Counter': 'vertical 4-2-1-3 with fixed DMF', 'Possession': 'short triangles + Orchestrator', 'Long Ball Counter': 'compact block + direct release', 'Out Wide': 'wide overload + weak-side cover', 'Long Ball': 'target outlet + second-ball midfield' },
    instructions: ['اختار Team Playstyle قبل التشكيلة.', 'ثبّت DMF أو ظهير دفاعي لحماية المرتدة.', 'استخدم 2 Attack + 2 Defence Instructions فقط عند الحاجة ولا تخلط المتعارض.', 'غيّر الخطة حسب Mobile/Console كإحساس لعب لا كسنة مختلفة.'],
    mistakes: ['اعتبار eFootball 2022-2026 ألعابًا منفصلة.', 'نسخ إعداد PES الرقمية داخل eFootball الحديثة.', 'رفع الظهيرين معًا بدون تغطية.', 'اختيار مدرب لا يناسب Playstyle.']
  },
  'efootball-2022': {
    formation: '4-2-3-1',
    identityAr: 'eFootball 2022 إصدار انتقالي؛ اللعب البسيط، التغطية، وقلة المخاطرة أهم من التركيبات المعقدة.',
    identityEn: 'eFootball 2022 is transitional; simple play, cover and low-risk decisions are essential.',
    defensiveStyle: 'Long Ball Counter / Medium Block',
    defensiveDetails: { 'Team Playstyle': 'Long Ball Counter', 'Defensive Line': 'Medium-Low', 'Compactness': 'High', 'Individual Instructions': 'Defensive on one fullback' },
    attackingStyle: 'Long Ball Counter',
    attackingDetails: { 'Team Playstyle': 'Long Ball Counter', 'Build Up Focus': 'Safe first pass', 'Attacking Area': 'Mixed', 'Support': 'Keep midfield triangle' },
    instructions: ['ثبّت ظهيرًا واحدًا.', 'اخرج بتمريرة آمنة قبل التسريع.', 'لا تترك قلب الدفاع في مواجهة فردية.'],
    mistakes: ['الضغط المستمر بلا تغطية.', 'تمريرات مخاطرة في العمق الدفاعي.', 'توسيع الفريق أكثر من اللازم.']
  },
  'efootball-2023': {
    formation: '4-2-1-3',
    identityAr: 'eFootball 2023 قوي في Quick Counter والتمرير البيني اليدوي مع أهمية تغطية العمق.',
    identityEn: 'eFootball 2023 favors Quick Counter and manual through passes while protecting central space.',
    defensiveStyle: 'Quick Counter / Front Pressure',
    defensiveDetails: { 'Team Playstyle': 'Quick Counter', 'Defensive Line': 'Medium', 'Compactness': 'High', 'Individual Instructions': 'Deep Line on DMF when needed' },
    attackingStyle: 'Quick Counter',
    attackingDetails: { 'Team Playstyle': 'Quick Counter', 'Build Up Focus': 'Vertical', 'Attacking Area': 'Centre to Wide', 'Player Playstyles': 'Goal Poacher + Hole Player' },
    instructions: ['استخدم Hole Player خلف المهاجم.', 'اربط الارتكاز بالخط الخلفي.', 'مرّر بينيًا بعد جذب لاعب الوسط.'],
    mistakes: ['تمرير بيني مبكر بلا حركة.', 'ترك العمق بعد فقد الكرة.', 'ضغط ثنائي يفتح الطرف العكسي.']
  },
  'efootball-2024': {
    formation: '4-2-3-1',
    identityAr: 'eFootball 2024 مرن في التحولات ويحتاج اختيار Team Playstyle مناسب لخصائص اللاعبين.',
    identityEn: 'eFootball 2024 is transition-heavy and requires a Team Playstyle that matches player profiles.',
    defensiveStyle: 'Quick Counter / Organized Press',
    defensiveDetails: { 'Team Playstyle': 'Quick Counter', 'Defensive Line': 'Medium', 'Compactness': 'High', 'Individual Instructions': 'Defensive fullback + Deep Line DMF' },
    attackingStyle: 'Quick Counter / Possession Hybrid',
    attackingDetails: { 'Team Playstyle': 'Quick Counter', 'Build Up Focus': 'One-two combinations', 'Attacking Area': 'Wide then inside', 'Player Playstyles': 'Prolific Winger + Hole Player' },
    instructions: ['استخدم جناحًا يثبت العرض وآخر يدخل للعمق.', 'فعّل Deep Line عند حماية التقدم.', 'غيّر الإيقاع بدل اللعب بسرعة واحدة.'],
    mistakes: ['اختيار Playstyle لا يناسب التشكيلة.', 'رفع الخط أمام السرعة.', 'الضغط المستمر مع لياقة منخفضة.']
  },
  'efootball-2025': {
    formation: '4-2-1-3',
    identityAr: 'eFootball 2025 سريع في التحولات؛ Quick Counter فعال لكن يحتاج ارتكازًا ثابتًا وتغطية الأظهرة.',
    identityEn: 'eFootball 2025 is fast in transition; Quick Counter works best with an anchored midfielder and covered fullbacks.',
    defensiveStyle: 'Quick Counter / Compact Press',
    defensiveDetails: { 'Team Playstyle': 'Quick Counter', 'Defensive Line': 'Medium', 'Compactness': 'Very High', 'Individual Instructions': 'Defensive on weak-side fullback' },
    attackingStyle: 'Quick Counter',
    attackingDetails: { 'Team Playstyle': 'Quick Counter', 'Build Up Focus': 'Fast vertical combinations', 'Attacking Area': 'Half-spaces', 'Player Playstyles': 'Goal Poacher + Creative Playmaker' },
    instructions: ['ثبّت الارتكاز كحارس للمساحة.', 'هاجم نصف المساحة بدل الجناح فقط.', 'احفظ تمريرة أمان عند فشل المرتدة.'],
    mistakes: ['إرسال الظهيرين معًا.', 'استمرار الاندفاع بعد ضياع المرتدة.', 'استخدام مهاجم لا يناسب Quick Counter.']
  },
  'efootball-2026': {
    formation: '4-2-3-1',
    identityAr: 'eFootball 2026 يعتمد على Playstyle DNA وتوازن الأدوار؛ لا تغيّر أسلوب الفريق بدون لاعبين مناسبين.',
    identityEn: 'eFootball 2026 relies on Playstyle DNA and role balance; avoid switching styles without suitable players.',
    defensiveStyle: 'Balanced Playstyle / Compact Block',
    defensiveDetails: { 'Team Playstyle': 'Quick Counter or Possession by squad', 'Defensive Line': 'Medium', 'Compactness': 'High', 'Individual Instructions': 'Role-based cover' },
    attackingStyle: 'Playstyle-led Build Up',
    attackingDetails: { 'Team Playstyle': 'Match squad DNA', 'Build Up Focus': 'Role-led', 'Attacking Area': 'Adaptive', 'Player Playstyles': 'Balanced combinations' },
    instructions: ['ابنِ الخطة حول أدوار اللاعبين الأساسيين.', 'احفظ توازنًا بين صانع اللعب والعدّاء.', 'استخدم تعليمات فردية محدودة وواضحة.'],
    mistakes: ['خلط Playstyles متعارضة.', 'تغيير الخطة بلا سبب.', 'إهمال التغطية أثناء التحول.']
  },
  'fifa-19': {
    formation: '4-2-3-1',
    identityAr: 'FIFA 19 يعتمد على Dynamic Tactics وTimed Finishing، لذلك تحتاج Presets واضحة وتحكمًا في التسديد.',
    identityEn: 'FIFA 19 relies on Dynamic Tactics and Timed Finishing, so clear presets and shot control matter.',
    defensiveStyle: 'Balanced',
    defensiveDetails: { 'Defensive Style': 'Balanced', 'Width': '45', 'Depth': '50', 'Dynamic Tactic Preset': 'Defensive / Balanced / Attacking prepared' },
    attackingStyle: 'Fast Build Up',
    attackingDetails: { 'Build Up Play': 'Fast Build Up', 'Chance Creation': 'Balanced', 'Width': '55', 'Players In Box': '6', 'Corners / Free Kicks': '2 / 2' },
    instructions: ['جهّز أكثر من Dynamic Tactic.', 'استخدم Stay Back على ارتكاز.', 'لا تعتمد على Timed Finishing في كل فرصة.'],
    mistakes: ['رفع العمق ضد السرعة.', 'التسديد المتسرع.', 'ترك منطقة الارتكاز فارغة.']
  },
  'fifa-20': {
    formation: '4-2-3-1',
    identityAr: 'FIFA 20 يكافئ الدفاع اليدوي، الصبر، والتمرير البيني في اللحظة الصحيحة.',
    identityEn: 'FIFA 20 rewards manual defending, patience and correctly timed through balls.',
    defensiveStyle: 'Balanced',
    defensiveDetails: { 'Defensive Style': 'Balanced', 'Width': '42', 'Depth': '45', 'Manual Defending': 'Jockey first, tackle second' },
    attackingStyle: 'Balanced / Possession',
    attackingDetails: { 'Build Up Play': 'Balanced', 'Chance Creation': 'Possession', 'Width': '50', 'Players In Box': '5', 'Corners / Free Kicks': '2 / 2' },
    instructions: ['CDM: Stay Back + Cover Center.', 'الظهيران: Stay Back ضد خصم سريع.', 'المهاجم: Stay Central + Get In Behind.'],
    mistakes: ['سحب قلب الدفاع خارج الخط.', 'تمرير بيني بلا توقيت.', 'ضغط Sprint أثناء الدفاع طوال الوقت.']
  },
  'fifa-21': {
    formation: '4-4-2',
    identityAr: 'FIFA 21 سريع ويبرز Agile Dribbling وCreative Runs؛ حماية الأطراف والعمق ضرورية.',
    identityEn: 'FIFA 21 is fast and highlights Agile Dribbling and Creative Runs; protect flanks and central gaps.',
    defensiveStyle: 'Balanced',
    defensiveDetails: { 'Defensive Style': 'Balanced', 'Width': '45', 'Depth': '48', 'Fullback Instruction': 'Stay Back While Attacking' },
    attackingStyle: 'Long Ball / Direct Runs',
    attackingDetails: { 'Build Up Play': 'Long Ball', 'Chance Creation': 'Forward Runs', 'Width': '55', 'Players In Box': '6', 'Corners / Free Kicks': '2 / 2' },
    instructions: ['استخدم Creative Runs بدل الجري المستقيم.', 'خلي جناحًا يرجع دفاعيًا.', 'لاعب الوسط: Cover Center.'],
    mistakes: ['ترك الظهير في 1v1 بلا مساعدة.', 'رفع Depth مع دفاع بطيء.', 'المبالغة في Agile Dribbling.']
  },
  'fifa-22': {
    formation: '4-2-2-2',
    identityAr: 'FIFA 22 أكثر تنظيمًا؛ البناء المتوازن والتمرير القصير داخل العمق أكثر أمانًا.',
    identityEn: 'FIFA 22 is more structured; balanced build-up and short central passing are safer.',
    defensiveStyle: 'Balanced',
    defensiveDetails: { 'Defensive Style': 'Balanced', 'Width': '45', 'Depth': '50', 'Second Man Press': 'Use selectively' },
    attackingStyle: 'Balanced / Direct Passing',
    attackingDetails: { 'Build Up Play': 'Balanced', 'Chance Creation': 'Direct Passing', 'Width': '48', 'Players In Box': '5', 'Corners / Free Kicks': '2 / 2' },
    instructions: ['أحد المهاجمين Come Back / False 9 حسب أسلوبك.', 'CDM ثابت والآخر Balanced.', 'استخدم التمرير القصير لجذب الخصم.'],
    mistakes: ['ضغط مبالغ فيه.', 'التمرير المركزي بلا دعم.', 'فتح المسافة بين ثنائي الارتكاز.']
  },
  'fifa-23': {
    formation: '4-3-2-1',
    identityAr: 'FIFA 23 يغيّر قيمة اللاعبين حسب AcceleRATE؛ اختَر الأدوار والجري وفق نوع اللاعب.',
    identityEn: 'FIFA 23 changes player value through AcceleRATE; choose roles and runs for each player type.',
    defensiveStyle: 'Balanced',
    defensiveDetails: { 'Defensive Style': 'Balanced', 'Width': '42', 'Depth': '55', 'AcceleRATE Cover': 'Keep a fast recovery defender' },
    attackingStyle: 'Balanced / Direct Passing',
    attackingDetails: { 'Build Up Play': 'Balanced', 'Chance Creation': 'Direct Passing', 'Width': '45', 'Players In Box': '6', 'Corners / Free Kicks': '2 / 2' },
    instructions: ['استخدم لاعب Lengthy في المساحات الطويلة.', 'ثبّت ظهيرًا واحدًا.', 'CF الجانبي يدخل للعمق.'],
    mistakes: ['دفاع بطيء أمام السرعة.', 'إرسال كلا الظهيرين.', 'اختيار أدوار لا تناسب AcceleRATE.']
  },
  'ea-fc-24': {
    formation: '4-2-3-1',
    identityAr: 'EA FC 24 يعتمد على PlayStyles وAcceleRATE؛ استغل قدرات اللاعبين بدل نسخ خطة عامة.',
    identityEn: 'EA FC 24 depends on PlayStyles and AcceleRATE; exploit player strengths instead of copying a generic tactic.',
    defensiveStyle: 'Balanced',
    defensiveDetails: { 'Defensive Style': 'Balanced', 'Width': '45', 'Depth': '55', 'PlayStyles Focus': 'Anticipate / Intercept in midfield' },
    attackingStyle: 'Balanced / Direct Passing',
    attackingDetails: { 'Build Up Play': 'Balanced', 'Chance Creation': 'Direct Passing', 'Width': '50', 'Players In Box': '5', 'PlayStyles Focus': 'Technical / Rapid / Pinged Pass' },
    instructions: ['استغل PlayStyle الأساسي لكل لاعب.', 'CDM: Cover Center.', 'الجناح الأسرع: Get In Behind.'],
    mistakes: ['اختيار لاعبين لا يناسبون الخطة.', 'ضغط دائم يهلك اللياقة.', 'تمريرات صعبة بلا PlayStyle مناسب.']
  },
  'ea-fc-25': {
    formation: '4-2-3-1',
    identityAr: 'EA FC 25 مبني على FC IQ وPlayer Roles؛ الدور والتركيز أهم من مجرد رقم التشكيل.',
    identityEn: 'EA FC 25 is built around FC IQ and Player Roles; role and focus matter more than formation numbers.',
    defensiveStyle: 'FC IQ Balanced Approach',
    defensiveDetails: { 'Defensive Approach': 'Balanced', 'Line Height': '45–55', 'CB Roles': 'Defender / Ball-Playing Defender', 'Fullback Roles': 'Fullback / Wingback by side' },
    attackingStyle: 'FC IQ Role-led Build Up',
    attackingDetails: { 'Build Up Style': 'Balanced', 'CAM Role': 'Playmaker', 'CM Roles': 'Holding + Box-to-Box', 'ST Role': 'Advanced Forward', 'Smart Tactics': 'Use situationally' },
    instructions: ['راجع Role Familiarity لكل لاعب.', 'ضع Holding أمام الدفاع.', 'استخدم Playmaker بين الخطوط.'],
    mistakes: ['تضارب Player Roles.', 'اختيار Focus هجومي لكل اللاعبين.', 'تجاهل Familiarity.']
  },
  'ea-fc-26': {
    formation: '4-3-2-1',
    identityAr: 'EA FC 26 يوسّع FC IQ وSmart Tactics؛ توازن الأدوار وتوافقها هو مفتاح الخطة.',
    identityEn: 'EA FC 26 expands FC IQ and Smart Tactics; balanced, compatible roles are the key.',
    defensiveStyle: 'FC IQ Balanced / Compact',
    defensiveDetails: { 'Defensive Approach': 'Balanced', 'Line Height': '50', 'GK Role': 'Ball-Playing Keeper when suitable', 'Backline Roles': 'One conservative, one progressive side' },
    attackingStyle: 'Smart Tactics / Role-led',
    attackingDetails: { 'Build Up Style': 'Balanced', 'Midfield Roles': 'Holding + Box Crasher + Playmaker', 'Wide Roles': 'Inside Forward / Wide Forward mix', 'Smart Tactics': 'Trigger only for match state' },
    instructions: ['وازن بين Box Crasher وHolding.', 'استخدم Ball-Playing Keeper فقط لو مناسب.', 'فعّل Smart Tactics حسب حالة المباراة.'],
    mistakes: ['تضارب الأدوار.', 'المبالغة في الأدوار الهجومية.', 'تغيير Smart Tactic كل دقيقة.']
  }
};

function counterFormation(style: string, profile: GameProfile): string {
  if (style.includes('ضغط عالي')) return profile.formation.includes('4-2') ? profile.formation : '4-2-3-1';
  if (style.includes('سرعة من الأطراف') || style.includes('عرضيات')) return '4-4-2';
  if (style.includes('استحواذ')) return '4-3-2-1';
  if (style.includes('دفاع متأخر')) return profile.formation.includes('3-') ? profile.formation : '4-3-3';
  if (style.includes('لعب من العمق')) return '4-2-3-1';
  return profile.formation;
}

export function generateLocalTactic(game: GameItem, input: GeneratorInput, lang: string): TacticResult {
  const profile = profiles[game.id] || profiles['ea-fc-25'];
  const ar = lang === 'ar';
  const formation = counterFormation(input.opponentStyle, profile);
  const reason = ar
    ? `${profile.identityAr} لذلك تم اختيار ${formation} ضد ${input.oppFormation} وأسلوب ${input.opponentStyle}، مع الحفاظ على طريقتك ${input.myStyle}.`
    : `${profile.identityEn} ${formation} is selected against ${input.oppFormation} and the opponent's ${input.opponentStyle} approach while preserving your ${input.myStyle} preference.`;

  const dna = officialDnaForGame(game.id);
  const defensiveDetails = { ...profile.defensiveDetails, ...officialDnaSummary(game, lang) };
  const attackingDetails = { ...profile.attackingDetails };

  const isEfootball = game.id.startsWith('efootball') || game.id.startsWith('pes');
  if (isEfootball) {
    attackingDetails[ar ? 'بروفايلات اللاعبين المقترحة' : 'Recommended Player Profiles'] = compactEfootballProfiles();
    defensiveDetails[ar ? 'قاعدة eFootball' : 'eFootball Rule'] = ar
      ? 'لا تبني الخطة على التشكيل فقط: اربط المدرب + Team Playstyle + Playing Style + تعليمات فردية.'
      : 'Do not build from formation only: combine manager + Team Playstyle + Playing Style + Individual Instructions.';
  }

  if (ar) {
    attackingDetails['لا تفعل'] = dna.avoid.join(' • ');
  } else {
    attackingDetails['Avoid'] = dna.avoid.join(' • ');
  }

  if (input.opponentStyle.includes('ضغط عالي')) {
    attackingDetails['Counter Adjustment'] = ar ? 'مخرج تمرير آمن + تبديل اللعب للطرف العكسي' : 'Safe outlet + switch to the weak side';
  }
  if (input.opponentStyle.includes('سرعة من الأطراف')) {
    defensiveDetails['Counter Adjustment'] = ar ? 'ثبّت الظهير البعيد وقلّل المسافة مع قلب الدفاع' : 'Hold the weak-side fullback and narrow the CB gap';
  }
  if (input.opponentStyle.includes('دفاع متأخر')) {
    attackingDetails['Counter Adjustment'] = ar ? 'وسّع الملعب ثم هاجم نصف المساحة' : 'Stretch the pitch, then attack the half-space';
  }

  const emergencyPlan = ar
    ? `لو متأخر بعد الدقيقة 75: تحوّل إلى 4-2-4، ارفع عدد اللاعبين حول الصندوق، واحتفظ بارتكاز واحد ضد المرتدة.`
    : 'If trailing after minute 75: switch to 4-2-4, increase box presence and retain one holding midfielder against counters.';
  const protectLeadPlan = ar
    ? `لو متقدم: قلّل المخاطرة، ثبّت الظهيرين، وحوّل الضغط إلى كتلة متوسطة بدون سحب قلوب الدفاع.`
    : 'If leading: lower risk, hold both fullbacks and defend in a medium block without dragging center-backs out.';

  const baseResult = {
    formation,
    reason,
    defensiveStyle: profile.defensiveStyle,
    defensiveDetails,
    attackingStyle: profile.attackingStyle,
    attackingDetails,
    playerInstructions: isEfootball ? [...profile.instructions, ...efootballProfileLines(lang).slice(0, 6)] : profile.instructions,
    inGameStrategy: ar
      ? `ابدأ أول 15 دقيقة بإيقاع متوازن لاختبار ضغط الخصم. عند استعادة الكرة، نفّذ أول تمريرتين بأمان ثم سرّع باتجاه نقطة الضعف. ${input.notes || ''}`
      : `Start the first 15 minutes balanced to read the opponent's press. After recovery, play two safe passes before accelerating toward the weak point. ${input.notes || ''}`,
    emergencyPlan,
    protectLeadPlan,
    mistakesToAvoid: profile.mistakes,
    difficulty: ar ? 'متوسطة — تحتاج التزامًا بالأدوار وتغييرًا هادئًا أثناء المباراة' : 'Medium — requires role discipline and calm in-match adjustments',
    confidence: `${Math.min(96, dna.score + (input.notes ? 2 : 0))}%`
  };

  return applyEfootballManagerToResult(input, baseResult, game.id, lang) as TacticResult;
}

